from ChatManager import ChatManager
import Config

#PROBLEM = "What is the date today?"
#PROBLEM = "What time is it now?"
PROBLEM = "Hey. I'd like to ask, what Accenture is?"

termination_msg = lambda x: isinstance(x, dict) and "TERMINATE" == str(x.get("content", ""))[-9:].upper()

groupChat = ChatManager(Config.GetLLMConfig(), termination_msg)

groupChat.start_chat(PROBLEM)