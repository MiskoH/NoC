from datetime import datetime

def getDateAndTime(date_part):

    if date_part == "date":
        return datetime.today().strftime('%Y-%m-%d')
    elif date_part == "time":
        return datetime.now().time()
    elif date_part == "both":
        return datetime.now()
    else:
        return "Bad Request!"
    

