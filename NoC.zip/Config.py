import autogen
from autogen.retrieve_utils import TEXT_FORMATS
import json

llm_config_list = autogen.config_list_from_json(
    "Configs/LLM_ConfigList.json",
    file_location=".",
    filter_dict={
        "model": ["gpt-3.5-turbo"],
    },
)

def GetLLMConfigList():
     return llm_config_list

def GetLLMConfig():
    with open('Configs/LLM_Config.json', 'r') as file:
        llm_config = json.load(file)
    
    llm_config["config_list"] = llm_config_list

    return llm_config

def GetAgentConfig(AgentName):
    with open('Configs/Agents.json', 'r') as file:
            AgentsConfig = json.load(file)

    return AgentsConfig[AgentName]