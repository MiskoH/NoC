import autogen
from UserProxyAgent import ProxyAgent
from AssistentAgent import AssistentAgent
from RAGAgent import RAGAgent
import FunctionsDef

class ChatManager:

    def __init__(self, config, termination_msg):
        self.config = config
        self.termination_msg = termination_msg

        self.user_proxy = ProxyAgent("User_proxy", self.termination_msg)
        self.chat_manager = AssistentAgent("Manager", self.termination_msg, self.config)
        
    def start_chat(self, question):  
        user_proxy = self.user_proxy.GetAgent()
        chat_manager = self.chat_manager.GetAgent()

        groupchat = autogen.GroupChat(
            agents = [user_proxy, chat_manager], 
            messages = [], 
            max_round = 120,
            speaker_selection_method = "auto",
            allow_repeat_speaker = False
        )

        other_config = {
            "timeout": 60,
            "cache_seed": 42,
            "config_list": "",
            "temperature": 0
        }

        other_config["config_list"] = autogen.config_list_from_json(
            "Configs/LLM_ConfigList.json",
            file_location=".",
            filter_dict={
                "model": ["gpt-3.5-turbo"],
            },
        )


        manager = autogen.GroupChatManager(groupchat = groupchat, llm_config = other_config)
        
        for agent in groupchat.agents:
            agent.reset()
        
        # Start chatting with boss as this is the user proxy agent.
        user_proxy.initiate_chat(
            manager,
            message = question,
        )