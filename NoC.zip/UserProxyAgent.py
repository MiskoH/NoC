import autogen
from autogen.retrieve_utils import TEXT_FORMATS
import Config

class ProxyAgent:

    def __init__(self, name, termination_msg):

        userProxyConfig = Config.GetAgentConfig(name)
        
        self.userProxyAgent = autogen.UserProxyAgent(
            name=name,
            is_termination_msg = termination_msg,
            system_message = userProxyConfig["prompt"],
            code_execution_config = {
                "use_docker": False
            },
            human_input_mode = userProxyConfig["human_input_mode"],
            default_auto_reply = userProxyConfig["default_auto_reply"]
        )

    def GetAgent(self):
        return self.userProxyAgent